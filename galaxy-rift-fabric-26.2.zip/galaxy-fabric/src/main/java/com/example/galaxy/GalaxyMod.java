package com.example.galaxy;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.resources.Identifier;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Items;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GalaxyMod implements ModInitializer {
	public static final String MOD_ID = "galaxy";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}

	@Override
	public void onInitialize() {
		ModBlocks.init();
		ModItems.init();
		ModEntities.init();
		CombatEvents.init();

		// Lighting the Rift Core: redstone power or 4 obsidian sides (scanned near players)...
		ServerTickEvents.END_SERVER_TICK.register(RiftWatcher::tick);

		// ...or flint and steel.
		UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
			if (level.isClientSide()) return InteractionResult.PASS;
			if (!level.getBlockState(hit.getBlockPos()).is(ModBlocks.RIFT_CORE)) return InteractionResult.PASS;
			if (!player.getItemInHand(hand).is(Items.FLINT_AND_STEEL)) return InteractionResult.PASS;
			RiftWatcher.start(level, hit.getBlockPos());
			return InteractionResult.SUCCESS;
		});

		LOGGER.info("Galaxy Rift loaded");
	}
}
