package com.example.galaxy;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;

/**
 * Finds lit Rift Cores near players and starts the ritual by summoning a marker entity.
 * The ritual itself (beam, cracked sky, pull, warp, boss) runs in data/galaxy/function/.
 */
public class RiftWatcher {
	private static final int RADIUS = 8;
	private static int counter = 0;

	public static void tick(MinecraftServer server) {
		if (++counter % 10 != 0) return;
		for (ServerPlayer player : server.getPlayerList().getPlayers()) {
			Level level = player.level();
			BlockPos c = player.blockPosition();
			BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
			for (int dx = -RADIUS; dx <= RADIUS; dx++) {
				for (int dy = -RADIUS; dy <= RADIUS; dy++) {
					for (int dz = -RADIUS; dz <= RADIUS; dz++) {
						p.set(c.getX() + dx, c.getY() + dy, c.getZ() + dz);
						if (level.getBlockState(p).is(ModBlocks.RIFT_CORE) && isLit(level, p)) {
							start(level, p.immutable());
						}
					}
				}
			}
		}
	}

	/** Redstone power, or obsidian on all 4 horizontal sides. */
	private static boolean isLit(Level level, BlockPos pos) {
		if (level.hasNeighborSignal(pos)) return true;
		for (Direction d : Direction.Plane.HORIZONTAL) {
			if (!level.getBlockState(pos.relative(d)).is(Blocks.OBSIDIAN)) return false;
		}
		return true;
	}

	/** Safe to call repeatedly: only one marker per core. */
	public static void start(Level level, BlockPos pos) {
		MinecraftServer server = level.getServer();
		if (server == null) return;
		String at = (pos.getX() + 0.5) + " " + pos.getY() + " " + (pos.getZ() + 0.5);
		String cmd = "execute in " + level.dimension().identifier() + " positioned " + at
				+ " unless entity @e[type=minecraft:marker,tag=galaxy_ritual,distance=..1]"
				+ " run summon minecraft:marker ~ ~ ~ {Tags:[\"galaxy_ritual\"]}";
		server.getCommands().performPrefixedCommand(server.createCommandSourceStack(), cmd);
	}
}
