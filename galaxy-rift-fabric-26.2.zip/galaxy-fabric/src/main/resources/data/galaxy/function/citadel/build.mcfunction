scoreboard players set #citadel galaxy_t 1
summon minecraft:marker ~ ~ ~ {Tags:["galaxy_citadel"]}
kill @e[type=galaxy:void_stalker,distance=..48]
fill ~-15 ~ ~-15 ~15 ~14 ~15 minecraft:air
fill ~-15 ~-5 ~-15 ~15 ~-2 ~15 minecraft:end_stone
fill ~-14 ~-1 ~-14 ~14 ~-1 ~14 minecraft:end_stone_bricks
fill ~-14 ~-1 ~-14 ~14 ~-1 ~14 minecraft:purpur_block outline
fill ~-1 ~-1 ~-14 ~1 ~-1 ~14 minecraft:smooth_quartz
fill ~-14 ~-1 ~-1 ~14 ~-1 ~1 minecraft:smooth_quartz
fill ~-14 ~ ~-14 ~14 ~3 ~-14 minecraft:end_stone_bricks
fill ~-14 ~ ~14 ~14 ~3 ~14 minecraft:end_stone_bricks
fill ~-14 ~ ~-14 ~-14 ~3 ~14 minecraft:end_stone_bricks
fill ~14 ~ ~-14 ~14 ~3 ~14 minecraft:end_stone_bricks
fill ~-2 ~ ~-14 ~2 ~2 ~-14 minecraft:air
fill ~-2 ~ ~14 ~2 ~2 ~14 minecraft:air
fill ~-14 ~ ~-2 ~-14 ~2 ~2 minecraft:air
fill ~14 ~ ~-2 ~14 ~2 ~2 minecraft:air
fill ~-14 ~ ~-14 ~-10 ~11 ~-10 minecraft:purpur_block hollow
fill ~-10 ~ ~-12 ~-10 ~1 ~-12 minecraft:air
fill ~-14 ~12 ~-14 ~-10 ~12 ~-10 minecraft:purpur_slab
setblock ~-12 ~12 ~-12 minecraft:sea_lantern
setblock ~-12 ~13 ~-12 minecraft:end_rod
setblock ~-12 ~4 ~-12 minecraft:light[level=15]
setblock ~-14 ~6 ~-12 minecraft:magenta_stained_glass
setblock ~-12 ~6 ~-14 minecraft:magenta_stained_glass
fill ~-14 ~ ~10 ~-10 ~11 ~14 minecraft:purpur_block hollow
fill ~-10 ~ ~12 ~-10 ~1 ~12 minecraft:air
fill ~-14 ~12 ~10 ~-10 ~12 ~14 minecraft:purpur_slab
setblock ~-12 ~12 ~12 minecraft:sea_lantern
setblock ~-12 ~13 ~12 minecraft:end_rod
setblock ~-12 ~4 ~12 minecraft:light[level=15]
setblock ~-14 ~6 ~12 minecraft:magenta_stained_glass
setblock ~-12 ~6 ~14 minecraft:magenta_stained_glass
fill ~10 ~ ~-14 ~14 ~11 ~-10 minecraft:purpur_block hollow
fill ~10 ~ ~-12 ~10 ~1 ~-12 minecraft:air
fill ~10 ~12 ~-14 ~14 ~12 ~-10 minecraft:purpur_slab
setblock ~12 ~12 ~-12 minecraft:sea_lantern
setblock ~12 ~13 ~-12 minecraft:end_rod
setblock ~12 ~4 ~-12 minecraft:light[level=15]
setblock ~14 ~6 ~-12 minecraft:magenta_stained_glass
setblock ~12 ~6 ~-14 minecraft:magenta_stained_glass
fill ~10 ~ ~10 ~14 ~11 ~14 minecraft:purpur_block hollow
fill ~10 ~ ~12 ~10 ~1 ~12 minecraft:air
fill ~10 ~12 ~10 ~14 ~12 ~14 minecraft:purpur_slab
setblock ~12 ~12 ~12 minecraft:sea_lantern
setblock ~12 ~13 ~12 minecraft:end_rod
setblock ~12 ~4 ~12 minecraft:light[level=15]
setblock ~14 ~6 ~12 minecraft:magenta_stained_glass
setblock ~12 ~6 ~14 minecraft:magenta_stained_glass
fill ~-3 ~-1 ~-3 ~3 ~ ~3 minecraft:purpur_block
fill ~-2 ~-1 ~-2 ~2 ~ ~2 minecraft:water
setblock ~ ~-1 ~ minecraft:sea_lantern
fill ~ ~ ~ ~ ~3 ~ minecraft:purpur_pillar
setblock ~ ~4 ~ minecraft:sea_lantern
fill ~-2 ~-1 ~-11 ~2 ~-1 ~-8 minecraft:amethyst_block
fill ~-2 ~ ~-11 ~-2 ~2 ~-11 minecraft:purpur_pillar
fill ~2 ~ ~-11 ~2 ~2 ~-11 minecraft:purpur_pillar
fill ~-2 ~3 ~-11 ~2 ~3 ~-11 minecraft:purpur_slab
setblock ~ ~ ~-10 minecraft:chest[facing=south]
loot insert ~ ~ ~-10 loot galaxy:chests/citadel
setblock ~-10 ~-1 ~-10 minecraft:sea_lantern
setblock ~-10 ~-1 ~-5 minecraft:sea_lantern
setblock ~-10 ~-1 ~5 minecraft:sea_lantern
setblock ~-10 ~-1 ~10 minecraft:sea_lantern
setblock ~-5 ~-1 ~-10 minecraft:sea_lantern
setblock ~-5 ~-1 ~-5 minecraft:sea_lantern
setblock ~-5 ~-1 ~5 minecraft:sea_lantern
setblock ~-5 ~-1 ~10 minecraft:sea_lantern
setblock ~5 ~-1 ~-10 minecraft:sea_lantern
setblock ~5 ~-1 ~-5 minecraft:sea_lantern
setblock ~5 ~-1 ~5 minecraft:sea_lantern
setblock ~5 ~-1 ~10 minecraft:sea_lantern
setblock ~10 ~-1 ~-10 minecraft:sea_lantern
setblock ~10 ~-1 ~-5 minecraft:sea_lantern
setblock ~10 ~-1 ~5 minecraft:sea_lantern
setblock ~10 ~-1 ~10 minecraft:sea_lantern
setblock ~-7 ~ ~-7 minecraft:amethyst_cluster[facing=up]
setblock ~7 ~ ~-7 minecraft:amethyst_cluster[facing=up]
setblock ~-7 ~ ~7 minecraft:amethyst_cluster[facing=up]
setblock ~7 ~ ~7 minecraft:amethyst_cluster[facing=up]
setblock ~-10 ~ ~0 minecraft:amethyst_cluster[facing=up]
setblock ~10 ~ ~0 minecraft:amethyst_cluster[facing=up]
setblock ~0 ~ ~10 minecraft:amethyst_cluster[facing=up]
setblock ~-4 ~ ~7 minecraft:amethyst_cluster[facing=up]
setblock ~4 ~ ~7 minecraft:amethyst_cluster[facing=up]
tellraw @a {"text":"A peaceful citadel rises from the stars. Hostile mobs cannot enter.","color":"light_purple"}
playsound minecraft:block.beacon.activate player @a ~ ~ ~ 4 1.2
particle minecraft:end_rod ~ ~2 ~ 10 3 10 0.1 300 force
