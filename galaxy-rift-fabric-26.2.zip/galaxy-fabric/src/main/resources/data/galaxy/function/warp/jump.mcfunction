effect clear @s minecraft:speed
effect clear @s minecraft:resistance
effect give @s minecraft:slow_falling 50 0 true
effect give @s minecraft:resistance 5 4 true
tp @s 0.5 201.5 6.5 0 30
scoreboard players set @s galaxy_c 1
playsound minecraft:item.elytra.flying player @s ~ ~ ~ 1 1
playsound minecraft:entity.ender_dragon.flap player @s ~ ~ ~ 2 0.8
