scoreboard players add @s galaxy_c 1
particle minecraft:end_rod ~1.5 ~-7 ~2.9 0 1 0 2.0 0 force @s
particle minecraft:end_rod ~5.3 ~-7 ~2.9 0 1 0 2.1 0 force @s
particle minecraft:end_rod ~-5.7 ~-7 ~-0.4 0 1 0 2.1 0 force @s
particle minecraft:end_rod ~1.8 ~-7 ~4.8 0 1 0 1.1 0 force @s
particle minecraft:end_rod ~-0.4 ~-7 ~-3.0 0 1 0 1.7 0 force @s
particle minecraft:end_rod ~0.9 ~-7 ~-5.8 0 1 0 1.3 0 force @s
particle minecraft:end_rod ~-2.6 ~-7 ~5.0 0 1 0 1.9 0 force @s
particle minecraft:end_rod ~-4.1 ~-7 ~3.6 0 1 0 1.2 0 force @s
particle minecraft:end_rod ~1.4 ~-7 ~-4.5 0 1 0 1.0 0 force @s
particle minecraft:end_rod ~4.5 ~-7 ~-3.5 0 1 0 1.3 0 force @s
particle minecraft:end_rod ~5.8 ~-7 ~4.5 0 1 0 1.3 0 force @s
particle minecraft:end_rod ~5.5 ~-7 ~0.5 0 1 0 1.8 0 force @s
particle minecraft:cloud ~ ~ ~ 2 2 2 0.05 3 normal
execute if score @s galaxy_c matches 2 run title @s times 5 40 10
execute if score @s galaxy_c matches 2 run title @s subtitle {"text":"Brace for Starfall...","color":"yellow"}
execute if score @s galaxy_c matches 2 run title @s title {"text":"JUMP!","color":"gold","bold":true}
execute if score @s galaxy_c matches 70 run title @s times 10 80 15
execute if score @s galaxy_c matches 70 run title @s subtitle {"text":"made by im_foxy","color":"aqua"}
execute if score @s galaxy_c matches 70 run title @s title {"text":"MADE FOR SKYSMP","color":"light_purple","bold":true}
execute if score @s galaxy_c matches 70 run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 1 0.6
execute if score @s galaxy_c matches 200 run title @s times 10 50 15
execute if score @s galaxy_c matches 200 run title @s subtitle {"text":"Land safely...","color":"gray"}
execute if score @s galaxy_c matches 200 run title @s title {"text":"STARFALL AWAITS","color":"dark_purple"}
execute if score @s galaxy_c matches 20.. if entity @s[nbt={OnGround:1b}] run function galaxy:warp/grounded
execute if score @s galaxy_c matches 20.. if entity @s[y=-100,dy=120] run function galaxy:warp/void_rescue
execute if score @s galaxy_c matches 900.. run function galaxy:warp/grounded
