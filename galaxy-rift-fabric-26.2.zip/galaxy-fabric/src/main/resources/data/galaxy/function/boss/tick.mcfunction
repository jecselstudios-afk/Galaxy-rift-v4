scoreboard players add @s galaxy_t 1
execute store result bossbar galaxy:warden value run data get entity @s Health 1
bossbar set galaxy:warden players @a[distance=..80]
particle minecraft:end_rod ~ ~2.2 ~ 1.4 2.0 1.4 0.02 4 normal
particle minecraft:dust{color:[0.6,0.2,1.0],scale:2.5} ~ ~2 ~ 1.2 1.8 1.2 0 6 normal
particle minecraft:portal ~ ~1 ~ 0.8 1.6 0.8 0.6 6 normal
execute store result score #m galaxy_t if entity @e[type=galaxy:void_stalker,tag=galaxy_minion,distance=..128]
execute if score #m galaxy_t < @s galaxy_p run function galaxy:boss/minion_killed
execute if score #m galaxy_t matches 30.. run tag @s add galaxy_filled
scoreboard players operation #b galaxy_t = @s galaxy_t
scoreboard players operation #b galaxy_t %= #160 galaxy_t
execute if score #b galaxy_t matches 0 unless entity @s[tag=galaxy_filled] if entity @p[distance=..40] if score #m galaxy_t matches ..27 run function galaxy:boss/summon
execute if score #b galaxy_t matches 0 unless entity @s[tag=galaxy_filled] if entity @p[distance=..40] if score #m galaxy_t matches 28..29 run function galaxy:boss/summon_one
execute store result score @s galaxy_p if entity @e[type=galaxy:void_stalker,tag=galaxy_minion,distance=..128]
scoreboard players operation #s galaxy_t = @s galaxy_t
scoreboard players operation #s galaxy_t %= #100 galaxy_t
execute if score #s galaxy_t matches 70..99 run particle minecraft:enchant ~ ~2.5 ~ 3 2 3 1 25 normal
execute if score #s galaxy_t matches 70..99 run particle minecraft:dust{color:[1.0,0.3,0.9],scale:1.5} ~ ~0.1 ~ 4 0 4 0 12 normal
execute if score #s galaxy_t matches 70 run playsound minecraft:block.beacon.power_select hostile @a ~ ~ ~ 4 0.6
execute if score #s galaxy_t matches 0 if entity @p[distance=..8] run function galaxy:boss/slam
execute store result score #hp galaxy_t run data get entity @s Health 1
execute if score #hp galaxy_t matches ..250 unless entity @s[tag=galaxy_enraged] run function galaxy:boss/enrage
execute if entity @s[tag=galaxy_enraged] run particle minecraft:dust{color:[1.0,0.1,0.5],scale:2.0} ~ ~1.8 ~ 1 1.8 1 0 8 normal
execute if entity @s[tag=galaxy_enraged] run effect give @s minecraft:speed 2 1 true
execute if entity @s[tag=galaxy_enraged] run effect give @s minecraft:strength 2 1 true
