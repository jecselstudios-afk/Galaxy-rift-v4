tag @s add galaxy_home
spawnpoint @s ~ ~ ~
tellraw @s {"text":"Spawn point set to the Starfall citadel.","color":"aqua"}
