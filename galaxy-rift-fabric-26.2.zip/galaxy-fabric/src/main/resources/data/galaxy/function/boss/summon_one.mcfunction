summon galaxy:void_stalker ~4 ~ ~-3 {Tags:["galaxy_minion"],PersistenceRequired:1b}
particle minecraft:reverse_portal ~4 ~1 ~-3 0.5 1 0.5 0.4 30 force
