effect give @s minecraft:speed 22 5 true
effect give @s minecraft:resistance 22 4 true
scoreboard players set @s galaxy_w 400
execute in galaxy:starfall run tp @s 0.5 201 0.5 0 0
title @s times 10 70 20
title @s subtitle {"text":"Engaging light-speed drive..."}
title @s title {"text":"WARP","color":"light_purple"}
playsound minecraft:block.end_portal.spawn ambient @s ~ ~ ~ 4 1.2
tag @s remove galaxy_warp
