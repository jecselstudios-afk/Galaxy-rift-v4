title @s times 20 140 40
title @s subtitle {"text":"Now you can enjoy Sky Dimension","color":"light_purple"}
title @s title {"text":"You have defeated the boss...","color":"gold","bold":true}
title @s actionbar {"text":"Made for SkySMP  -  made by im_foxy","color":"aqua"}
particle minecraft:totem_of_undying ~ ~1 ~ 3 2 3 0.6 200 force
particle minecraft:end_rod ~ ~ ~ 4 0 4 0.5 120 force
playsound minecraft:ui.toast.challenge_complete player @s ~ ~ ~ 1 1
playsound minecraft:entity.firework_rocket.twinkle player @s ~ ~ ~ 2 1
kill @e[type=galaxy:void_stalker,tag=galaxy_minion]
schedule clear galaxy:boss/respawn_minion
execute unless score #citadel galaxy_t matches 1 run function galaxy:citadel/build
advancement revoke @s only galaxy:boss_kill
