summon galaxy:galaxy_warden ~20 ~ ~ {PersistenceRequired:1b}
execute positioned ~20 ~ ~ run function galaxy:boss/spawn_fx
tellraw @a[distance=..200] {"text":"The Galaxy Warden awakens...","color":"dark_purple"}
