effect clear @s minecraft:slow_falling
effect clear @s minecraft:resistance
scoreboard players reset @s galaxy_c
title @s times 10 60 20
title @s subtitle {"text":"Stronger mobs. Better loot.","color":"light_purple"}
title @s title {"text":"STARFALL","color":"dark_purple","bold":true}
playsound minecraft:block.beacon.activate player @s ~ ~ ~ 2 1.5
execute unless entity @e[type=galaxy:galaxy_warden,distance=..500] unless score #citadel galaxy_t matches 1 run function galaxy:boss/spawn
