fill -4 201 -4 4 204 4 minecraft:barrier hollow
fill -4 200 -4 4 200 4 minecraft:bedrock
fill -4 201 -4 -4 204 -4 minecraft:bedrock
fill 4 201 -4 4 204 -4 minecraft:bedrock
fill -4 201 4 -4 204 4 minecraft:bedrock
fill 4 201 4 4 204 4 minecraft:bedrock
fill -4 204 -4 4 204 -4 minecraft:bedrock
fill -4 204 4 4 204 4 minecraft:bedrock
fill -4 204 -4 -4 204 4 minecraft:bedrock
fill 4 204 -4 4 204 4 minecraft:bedrock
setblock 0 203 0 minecraft:light[level=15]
setblock 2 203 2 minecraft:light[level=15]
setblock -2 203 2 minecraft:light[level=15]
setblock 2 203 -2 minecraft:light[level=15]
setblock -2 203 -2 minecraft:light[level=15]
