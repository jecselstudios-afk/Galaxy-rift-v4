fill -1 201 4 1 203 4 minecraft:air
playsound minecraft:block.piston.extend ambient @s ~ ~ ~ 2 0.7
playsound minecraft:block.iron_door.open ambient @s ~ ~ ~ 2 0.6
title @s actionbar {"text":"Hatch opening... get ready to jump!","color":"yellow"}
particle minecraft:cloud 0.5 202 4 1 1 0.3 0.2 40 force @s
