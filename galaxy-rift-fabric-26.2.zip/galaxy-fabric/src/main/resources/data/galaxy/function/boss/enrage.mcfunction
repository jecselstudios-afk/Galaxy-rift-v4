tag @s add galaxy_enraged
title @a[distance=..80] title {"text":"THE WARDEN IS ENRAGED","color":"red"}
playsound minecraft:entity.ender_dragon.growl hostile @a ~ ~ ~ 12 0.5
particle minecraft:explosion_emitter ~ ~1 ~ 1 1 1 0 3 force
particle minecraft:reverse_portal ~ ~1 ~ 3 2 3 0.5 150 force
