particle minecraft:reverse_portal ~ ~1 ~ 2 2 2 0.8 200 force
particle minecraft:explosion_emitter ~ ~1 ~ 0 0 0 0 1 force
particle minecraft:end_rod ~ ~0 ~ 0.6 0 0.6 0.4 120 force
playsound minecraft:entity.ender_dragon.growl hostile @a ~ ~ ~ 12 0.7
playsound minecraft:entity.wither.spawn hostile @a ~ ~ ~ 4 1.2
effect give @e[type=galaxy:galaxy_warden,distance=..3] minecraft:resistance 4 4 true
