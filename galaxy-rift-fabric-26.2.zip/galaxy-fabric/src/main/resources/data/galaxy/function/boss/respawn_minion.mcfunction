execute in galaxy:starfall as @e[type=galaxy:galaxy_warden,limit=1] at @s store result score #c galaxy_t if entity @e[type=galaxy:void_stalker,tag=galaxy_minion,distance=..128]
execute in galaxy:starfall as @e[type=galaxy:galaxy_warden,limit=1] at @s if score #c galaxy_t matches ..29 run function galaxy:boss/summon_one
