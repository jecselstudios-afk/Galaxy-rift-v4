kill @e[type=galaxy:void_stalker,distance=..32]
effect give @a[distance=..16] minecraft:regeneration 3 0 true
effect give @a[distance=..16] minecraft:saturation 3 0 true
effect give @a[distance=..16] minecraft:resistance 3 3 true
execute as @a[distance=..10,tag=!galaxy_home] run function galaxy:citadel/claim
