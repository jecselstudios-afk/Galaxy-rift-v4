execute unless block 0 200 0 minecraft:bedrock run function galaxy:warp/build_ship_now
fill -1 201 4 1 203 4 minecraft:barrier
