schedule function galaxy:boss/respawn_minion 600t append
scoreboard players remove #k galaxy_t 1
execute if score #k galaxy_t matches 1.. run function galaxy:boss/queue_respawn
