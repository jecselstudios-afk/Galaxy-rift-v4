execute in galaxy:starfall run spreadplayers 0 0 0 16 false @s
function galaxy:warp/grounded
