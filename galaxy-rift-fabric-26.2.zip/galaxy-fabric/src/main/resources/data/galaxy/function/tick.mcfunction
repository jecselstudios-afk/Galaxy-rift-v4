execute as @e[type=minecraft:marker,tag=galaxy_ritual] at @s run function galaxy:ritual/tick
execute as @a[scores={galaxy_w=1..}] at @s run function galaxy:warp/tick
execute as @e[type=galaxy:galaxy_warden] at @s run function galaxy:boss/tick
execute in galaxy:starfall unless entity @e[type=galaxy:galaxy_warden] run bossbar set galaxy:warden players
execute as @a at @s if items entity @s armor.head galaxy:starforged_helmet if items entity @s armor.chest galaxy:starforged_chestplate if items entity @s armor.legs galaxy:starforged_leggings if items entity @s armor.feet galaxy:starforged_boots run function galaxy:armor/bonus
execute as @e[type=galaxy:void_stalker] at @s run particle minecraft:portal ~ ~1 ~ 0.3 0.7 0.3 0.15 3 normal
execute as @e[type=galaxy:void_stalker] at @s run particle minecraft:dust{color:[0.9,0.2,1.0],scale:1.0} ~ ~1.7 ~ 0.2 0.1 0.2 0 1 normal
execute as @e[type=minecraft:marker,tag=galaxy_citadel] at @s run function galaxy:citadel/tick
execute as @a[scores={galaxy_c=1..}] at @s if dimension galaxy:starfall run function galaxy:warp/cutscene
execute as @a[scores={galaxy_c=1..}] at @s unless dimension galaxy:starfall run scoreboard players reset @s galaxy_c
execute as @a[scores={galaxy_w=1..}] at @s unless dimension galaxy:starfall run scoreboard players reset @s galaxy_w
