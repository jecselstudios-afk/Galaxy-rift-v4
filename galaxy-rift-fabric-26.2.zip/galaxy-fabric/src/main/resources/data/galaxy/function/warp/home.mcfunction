execute in minecraft:overworld run spreadplayers 0 0 0 48 false @s
title @s title {"text":"HOME","color":"aqua"}
