scoreboard players operation #k galaxy_t = @s galaxy_p
scoreboard players operation #k galaxy_t -= #m galaxy_t
function galaxy:boss/queue_respawn
