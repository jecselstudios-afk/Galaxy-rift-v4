summon galaxy:void_stalker ~4 ~ ~3 {Tags:["galaxy_minion"],PersistenceRequired:1b}
summon galaxy:void_stalker ~-4 ~ ~3 {Tags:["galaxy_minion"],PersistenceRequired:1b}
summon galaxy:void_stalker ~0 ~ ~-4 {Tags:["galaxy_minion"],PersistenceRequired:1b}
particle minecraft:reverse_portal ~ ~1 ~ 3 1 3 0.4 60 force
