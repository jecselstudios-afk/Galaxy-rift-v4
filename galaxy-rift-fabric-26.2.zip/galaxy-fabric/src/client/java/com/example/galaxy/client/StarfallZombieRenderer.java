package com.example.galaxy.client;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.ZombieRenderer;
import net.minecraft.client.renderer.entity.state.ZombieRenderState;
import net.minecraft.resources.Identifier;

/** Vanilla zombie model with our own skin. */
public class StarfallZombieRenderer extends ZombieRenderer {
	private final Identifier texture;

	public StarfallZombieRenderer(EntityRendererProvider.Context context, Identifier texture) {
		super(context);
		this.texture = texture;
	}

	@Override
	public Identifier getTextureLocation(ZombieRenderState state) {
		return texture;
	}
}
