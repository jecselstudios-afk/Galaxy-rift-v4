package com.example.galaxy.client;

import com.example.galaxy.GalaxyMod;
import com.example.galaxy.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.monster.zombie.Zombie;

public class GalaxyClient implements ClientModInitializer {
	private static final Identifier STALKER = GalaxyMod.id("textures/entity/void_stalker.png");
	private static final Identifier WARDEN = GalaxyMod.id("textures/entity/galaxy_warden.png");

	@Override
	public void onInitializeClient() {
		EntityRendererRegistry.<Zombie>register(ModEntities.VOID_STALKER, ctx -> new StarfallZombieRenderer(ctx, STALKER));
		EntityRendererRegistry.<Zombie>register(ModEntities.GALAXY_WARDEN, ctx -> new StarfallZombieRenderer(ctx, WARDEN));
	}
}
